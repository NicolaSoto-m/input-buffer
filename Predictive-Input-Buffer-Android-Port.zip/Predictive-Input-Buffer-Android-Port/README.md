# Predictive Input Buffer — Android port work-in-progress

This project adapts the supplied Windows-only Geode source to include Android support.

## Changes in this port
- Removes the unconditional `Windows.h` dependency.
- Compiles console allocation, console redirection, and F6 polling only on Windows.
- Adds Android Geode settings for enable/disable and normal/wave tick limits (0–80 ticks each).
- Applies Android setting changes immediately and clears pending buffered input when settings change.
- Targets Geometry Dash 2.2081 on Android and Windows in `mod.json`.

## Important
This is a **source port, not a compiled `.geode` mod**. The uploaded `.geode` file contains a Windows DLL, and cannot be made into an Android build by renaming it. An Android `.geode` must be compiled against a compatible Geode SDK / Android NDK toolchain and tested on-device.

The original simulation code has not yet been runtime-tested on Android. Higher tick limits may still cause gameplay stutter because the prediction routine simulates multiple future ticks per input. Start with 2 normal / 2 wave ticks, then increase only if it stays smooth.

## Build
Install the Geode SDK/toolchain for Android and configure `GEODE_SDK` to point at it, then build using the Geode SDK's documented Android workflow. The exact commands depend on the installed SDK/toolchain and game target.
