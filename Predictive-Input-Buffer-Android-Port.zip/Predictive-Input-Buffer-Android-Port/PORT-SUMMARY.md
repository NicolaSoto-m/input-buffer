# Port summary

- `src/main.cpp`: Windows-only APIs are now guarded with `_WIN32`; Android uses Geode settings for live enable/disable and normal/wave delay configuration.
- `mod.json`: declares Android Geometry Dash 2.2081 and exposes Android settings.
- `CMakeLists.txt`: retains the Geode SDK build integration.
- `README.md`: documents build/test status and safe initial settings.

Status: source adaptation only. No Android `.geode` binary was built because no Geode SDK / Android NDK build environment is present in this session. It must be compiled and tested before installation.
